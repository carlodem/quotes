<?php /** @var \Kirby\Cms\Block $block */ ?>
<?= $block->text();
